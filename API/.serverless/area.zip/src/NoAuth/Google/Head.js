const utils = require("../../Utils");
const dynamo = require("../../../DB");

const dataGoogle = async (req, res) => {
    res.status(200).send();
}

module.exports = dataGoogle;